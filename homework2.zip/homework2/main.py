Homework_number = 12
Hours = 1.5
Course_name = 'Python,'
hours_per_homework = (Hours / Homework_number)
print('Курс:', Course_name, 'всего задач:', Homework_number,',', 'затрачено часов:', Hours,',','среднее время выполнения:', hours_per_homework, 'часа.')
